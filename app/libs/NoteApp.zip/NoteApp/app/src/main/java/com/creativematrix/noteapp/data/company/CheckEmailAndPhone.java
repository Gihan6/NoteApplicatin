package com.creativematrix.noteapp.data.company;

public class CheckEmailAndPhone {
    public String flag;
    public String lang;
    public String Email;
    public String Message;

    public CheckEmailAndPhone(String flag, String lang, String email, String message) {
        this.flag = flag;
        this.lang = lang;
        Email = email;
        Message = message;
    }

}
