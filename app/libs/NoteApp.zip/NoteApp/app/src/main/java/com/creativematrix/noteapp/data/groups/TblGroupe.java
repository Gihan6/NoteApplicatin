
package com.creativematrix.noteapp.data.groups;

import com.google.gson.annotations.Expose;

@SuppressWarnings("unused")
public class TblGroupe {

    @Expose
    private String $ref;

    public String get$ref() {
        return $ref;
    }

    public void set$ref(String $ref) {
        this.$ref = $ref;
    }

}
